<?php

require_once 'lib/ZabbixApi.class.php';
require_once 'conf/conf.php';

use ZabbixApi\ZabbixApi;

//metodos para conectar zabbix
try
{
    // connect to Zabbix API
    $api = new ZabbixApi('http://'.$ip_zbx.'/zabbix/api_jsonrpc.php', $user_zbx, $passwd);

    /* ... do your stuff here ... */
}
catch(Exception $e)
{
    // Exception in ZabbixApi catched
    echo $e->getMessage();
}

function event_ack($eventid,$message,$api){
	$events = $api->eventAcknowledge(array(
		'eventids' => $eventid,
		'action' => 2,
		'message'=> $message
		));
	//return date('d/m/Y H:i',$retorno);
	$retorno='ACK Criado com sucesso';
	return $retorno;
}

function event_ack_message($eventid,$message,$api){
	$events = $api->eventAcknowledge(array(
		'eventids' => $eventid,
		'action' => 4,
		'message'=> $message
		));
	//return date('d/m/Y H:i',$retorno);
	$retorno='</br>Menssagem Inserida no reconhecimento do evento';
	return $retorno;
}









$eventid=$_POST['eventid'];
$message=$_POST['message'];

echo event_ack($eventid,$message,$api);
echo event_ack_message($eventid,$message,$api);

header("refresh: 5;dashboard.php");

?>
