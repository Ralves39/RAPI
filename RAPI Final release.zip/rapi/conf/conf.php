<?php
//Configura��o de acesso ao front End zabbix-API
$user_zbx='Admin';
$passwd='zabbix';
$ip_zbx='localhost';

///////////////////////////////
//itens de disco
//tempo de coleta do item
$diskcoleta=5;
//em dias
$disktime=15;
//treshould para o sla de disco treshloud do template do zabbix (m porcentagem)
$disktreshloud=9.7;
//itemname
$diskitemname='Used disk space';
//key
$diskitemkey='pused';
//pega o nome do diretorio
$explodedisk=4;

/////////////////////////////////

?>