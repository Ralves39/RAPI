<?php

//bibliotecas
require_once 'lib/ZabbixApi.class.php';
require_once 'conf/conf.php';

use ZabbixApi\ZabbixApi;

//metodos para conectar zabbix
try
{
    // connect to Zabbix API
    $api = new ZabbixApi('http://'.$ip_zbx.'/zabbix/api_jsonrpc.php', $user_zbx, $passwd);

    /* ... do your stuff here ... */
}
catch(Exception $e)
{
    // Exception in ZabbixApi catched
    echo $e->getMessage();
}


/////////metodos gettriggers e gerador de relatorio de triggers por host

//triger getMessage

function trigger_get($triggerid,$hostid,$api){
	$triggers = $api->triggerGet(array(
        'output' => 'extend',
		'triggerids' => $triggerid,
		'selectFunctions' => 'extend'
		));
		foreach($triggers as $trigger){

	echo $trigger->triggerid.':'.$trigger->description;
	echo '<br>';
		}
}

//tras o id das triggers
function get_trriggerids($hostid,$api){
	$triggers = $api->triggerGet(array(
        'output' => 'extend',
		'hostids' => $hostid,
		'selectFunctions' => 'extend'
		));
		$valor=array();
		foreach($triggers as $trigger){

	$valor[]=$trigger->triggerid;

		}
		return $valor;
}


//printa o trigersid a express��o e a descri��o das triggers ativas

function get_trriggers_desc($hostname,$hostid,$api){
	$triggers = $api->triggerGet(array(
        'output' => 'extend',
		'hostids' => $hostid,
		'selectFunctions' => 'extend',
		'active' => 0,
		'sortorder' => 'DESC'
		));
		echo "<div class=\"container\"><h2 class=\"float-left\">Triggers Ativas: ".$hostname."</h2><b><p class=\"float-right\">".date('l jS \of F Y h:i:s A')."</p></b>";
		echo "<table class=\"table table-striped\"><thead class=\"thead-light\"><tr><th>ID Trigger</th><th>Descricao</th><th>Expressao</th><th>Severidade</th>";
		foreach($triggers as $trigger){

		echo "<tr><td>".$trigger->triggerid."</td><td>".$trigger->description."</td><td>".$trigger->expression;
		$prioridade = $trigger->priority;
		//echo $prioridade;
		if ($prioridade == 5){
			echo "</td><td bgcolor=\"#FF0000\">Disaster</td><tr>";
			
		}elseif($prioridade == 4){
			echo "</td><td bgcolor=\"#FE2E2E\">High</td><tr>";
		}elseif($prioridade == 3){
			echo "</td><td bgcolor=\"#FF8000\">Average</td><tr>";
		}elseif($prioridade == 2){
			echo "</td><td bgcolor=\"#FFFF00\">Warning</td><tr>";
		}elseif($prioridade == 1){
			echo "</td><td bgcolor=\"#00BFFF\">Information</td><tr>";
		}elseif($prioridade == 0){
			echo "</td><td bgcolor=\"#CCCCCC\">N�o Classificado</td><tr>";
		}
		
		}
		echo "</tbody></table></div>";
}


//pega o hostid
function get_hostid($hostname,$api){
	$hosts = $api->hostGet(array(
        'output' => 'extend',
        'filter' => array('name' => $hostname)));
		foreach($hosts as $host)

	return $host->hostid;
}


function get_itemid($hostid,$itemkey,$api){
	$itens = $api->itemGet(array(
        'output' => 'extend',
		'hostids' => $hostid,
        'search' => array('key_' => $itemkey),
		'sortfield' => 'name'
		));
		foreach($itens as $item){

	echo $item->itemid.':'.$item->key_;
	echo '<br>';
		}
}

$hostname=$_GET["hostname"];

$hostid=get_hostid($hostname,$api);


//trigger_get(13493,10084,$api);
//$return = get_trriggerids(10084,$api);

//print_r($return);



?>
<html>
<head>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB" crossorigin="anonymous">
<link rel="stylesheet" href="./css/rapi.css">
</head>

<?php get_trriggers_desc($hostname,$hostid,$api); ?>

</html>




