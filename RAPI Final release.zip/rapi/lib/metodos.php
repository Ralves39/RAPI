<?php

//bibliotecas
require_once 'lib/ZabbixApi.class.php';
require_once 'conf/conf.php';
use ZabbixApi\ZabbixApi;

//metodos para conectar zabbix
try
{
    // connect to Zabbix API
    $api = new ZabbixApi('http://'.$ip_zbx.'/zabbix/api_jsonrpc.php', $user_zbx, $passwd);

    /* ... do your stuff here ... */
}
catch(Exception $e)
{
    // Exception in ZabbixApi catched
    echo $e->getMessage();
}

//calculos do programa
//determina a variavel de numero de coletas dos items
function num_coletas($numcol,$dias){
	$coletas=(($dias*24)*60)/$numcol;
	return $coletas;
}
// Fun��o de porcentagem: N � X% de N
function porcentagem_nx ( $parcial, $total ) {
    return ( $parcial * 100 ) / $total;
}

//funcoes de get
//hostid
function get_hostid($hostname,$api){
	$hosts = $api->hostGet(array(
        'output' => 'extend',
        'filter' => array('name' => $hostname)));
		foreach($hosts as $host)

	return $host->hostid;
}

function get_itemid($hostid,$itemkey,$api){
	$itens = $api->itemGet(array(
        'output' => 'extend',
		'hostids' => $hostid,
        'search' => array('key_' => $itemkey),
		'sortfield' => 'name'
		));
		foreach($itens as $item){

	echo $item->itemid.':'.$item->key_;
	echo '<br>';
		}
}
//tras o id pelo nome do item
function get_itemid_byname($hostid,$itemname,$api){
	$itens = $api->itemGet(array(
        'output' => 'extend',
		'hostids' => $hostid,
        'search' => array('name' => $itemname),
		'sortfield' => 'name'
		));
		foreach($itens as $item){

	echo $item->itemid.':'.$item->key_.':'.$item->name;
	echo '<br>';
		}
}

//tras a descri��o do item
function get_itedesc_byname($hostid,$itemid,$api){
	$itens = $api->itemGet(array(
        'output' => 'extend',
		'hostids' => $hostid,
		'itemids' => $itemid,
		'sortfield' => 'name'
		));
		foreach($itens as $item){

	return $item->name;
		}
}


//tras por parte do nome e pela key
function get_itemid_bynameandid($hostid,$itemname,$itemkey,$api){
	$itens = $api->itemGet(array(
        'output' => 'extend',
		'hostids' => $hostid,
        'search' => array('name' => $itemname,'key_' => $itemkey),
		'sortfield' => 'name'
		));
		$valor=array();
		foreach($itens as $item){

	$valor[]=$item->itemid;

		}
		return $valor;
}

//tras nome do host

function get_hostname($hostid,$api){
	$hosts = $api->hostGet(array(
        'hostids' => $hostid,
		'output' => 'extend'
		));
		foreach($hosts as $host){

	return $host->host;
		}
}


//Pega history do item $itemtipe (tipo de item do zabbix float unisig etc)
function get_item_history($itemid,$itemtipe,$limit,$api){
	$historys = $api->historyGet(array(
        'output' => 'extend',
		'history' => $itemtipe,
		'itemids' => $itemid,
		'sortfield' => 'clock',
		'sortorder' => 'DESC',
		'limit' => $limit
		));
		$valor=array();
		foreach($historys as $history){

	$valor[]=$history->value;

		}
		return $valor;
}

//funcao para pegar os ultimos valores
function get_diskvalues($hostid,$itemname,$itemkey,$explodedisk,$api){
$itemid=get_itemid_bynameandid($hostid,$itemname,$itemkey,$api);
foreach($itemid as $item){

	$desc = get_itedesc_byname($hostid,$item,$api);
	$desc = explode(" ",$desc);
	$values = get_item_history($item,0,1,$api);
	
	foreach($values as $value){

					echo '<li class="text-center text-light list-group-item col-lg-5 float-left m-2 bg-dark"><b>Disk: '.$desc[$explodedisk].'</b><br><b><h3>'.number_format($value, 2, '.', '').'%</h3></b></li>';
				
			}
	
}

}


//funcoes de sla
//funcao para pegar sla de disco
function get_disksla($hostid,$itemname,$itemkey,$diskcoleta,$disktime,$disktreshloud,$api){
$itemid=get_itemid_bynameandid($hostid,$itemname,$itemkey,$api);
//print_r($itemid);
$mastersla=0;
$contagemmastersla=0;
foreach($itemid as $item){
	$countsla=0;
	
	//echo 'ItemID:'.$item.'<br>';
	$mostra = get_itedesc_byname($hostid,$item,$api);
	//echo 'Item:'.$mostra.'<br>';
	$coleta = num_coletas($diskcoleta,$disktime);
	
	
	$values = get_item_history($item,0,$coleta,$api);
			foreach($values as $value){
				//mostra os valores
				//echo $value.';';
				if ($value>$disktreshloud){
					$countsla=$countsla+1;
				}
			}
	//echo '<br>';
	
	$sla=100-porcentagem_nx ($countsla, $coleta );
	//echo 'SLA = '.$sla.'%<br>';
	$mastersla=$sla+$mastersla;
	$contagemmastersla++;
	$sla=0;
	$countsla=0;
	
}
$mastersla=$mastersla/$contagemmastersla;
//echo 'SLA - Total de disco: '.$mastersla.'%<br>';
//echo num_coletas($diskcoleta,$disktime);
return $mastersla;
}

//monta grafico de sla
function mont_sla($hostname,$disco,$memoria,$cpu,$agent_ping,$icmp,$api){
	
echo	"
<script>
	
Highcharts.chart('sla', {
    chart: {
        type: 'bar'
    },
    title: {
        text: 'SLA'
    },
    subtitle: {
        text: '".$hostname."'
    },
    xAxis: {
        categories: ['Label', 'Disco', 'Memoria', 'CPU', 'Zabbix Agent', 'ICMP'],
        title: {
            text: null
        }
    },
    yAxis: {
        min: 0,
        title: {
            text: '% SLA',
            align: 'high'
        },
        labels: {
           
        }
    },
    tooltip: {
        valueSuffix: '%'
    },
    plotOptions: {
        bar: {
            dataLabels: {
                enabled: true
            }
        }
    },
    legend: {
        layout: 'vertical',
        align: 'right',
        verticalAlign: 'top',
        x: -40,
        y: 100,
        floating: true,
        borderWidth: 1,
        backgroundColor: ((Highcharts.theme && Highcharts.theme.legendBackgroundColor) || '#FFFFFF'),
        shadow: true
    },
    credits: {
        enabled: false
    },
    series: [{
        name: 'Zabbix server',
        data: [0,".$disco.", ".$memoria.", ".$cpu.", ".$agent_ping.", ".$icmp."]
    }]
});
	</script>";
	
	
}


?>