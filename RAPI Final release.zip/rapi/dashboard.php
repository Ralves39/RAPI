<?php

$refreshtime =$_GET['refresh'];
if(empty($refreshtime))
{
$refreshtime = 30;
}

require_once 'lib/ZabbixApi.class.php';
require_once 'conf/conf.php';

use ZabbixApi\ZabbixApi;

//metodos para conectar zabbix
try
{
    // connect to Zabbix API
    $api = new ZabbixApi('http://'.$ip_zbx.'/zabbix/api_jsonrpc.php', $user_zbx, $passwd);

    /* ... do your stuff here ... */
}
catch(Exception $e)
{
    // Exception in ZabbixApi catched
    echo $e->getMessage();
}


///eventos ativos
//conta o numero de ventos por hostgroup
function get_hostgroup($api){
	$groups = $api->hostGroupGet(array(
        'output' => 'extend'
		));
		$retorno=array();
		foreach($groups as $group){
			//array push incrimenta o valor no array no caso com o nome dos grupos
			array_push($retorno,$group->name);
		}
return $retorno;
	
}

function dash_countgroups($api){
	$triggers = $api->triggerGet(array(
        'only_true' => 1,
		'filter' =>  (array('value'=>1)),
		'monitored' => 1,
		'active' => 1,
		'skipDependent' => 1,
		'output' => 'extend',
		'expandDescription' => 1,
		'selectLastEvent'=>	'extend',
		'selectHosts' =>  (array('host')),
		'selectGroups' => (array('name')),
		'sortfield'=> 'lastchange',
		'sortorder'=> 'DESC'
		));
	
		$grupos=get_hostgroup($api);
		$qtd=array('grupo'=>0,'main'=>0);
		$value=0;
		foreach($grupos as $grupo){	
			array_push($qtd[$grupo]=$value,$qtd[$grupo.'main']=$value);
		}
		

		
		//print_r($qtd);
		//echo '<br>';
		//echo $qtd['Jmeter'];
		//$teste = $qtd['Jmeter'] +1;
		//echo '<br>'.$teste;
		foreach($triggers as $trigger){
		
			$groups = $trigger->groups;
			//print_r($groups);
			
			//print_r($groups);
			foreach($groups as $group){
				//echo $group->name."/";
				foreach($grupos as $grupo){
				if($group->name==$grupo)
				$qtd[$grupo]++;
				}
			}
				
		
}

$grupomaintance=verify_groupmaintance($api);

foreach($grupos as $grupo){
	$teste=0;//verify_group_maintance2('PROXYUPDATE',$api);
	//echo $teste;
	if($teste==1){
		$qtd[$grupo.'main']++;
		echo $qtd[$grupo.'main'];
	}
}
//print_r($grupomaintance);

foreach($grupos as $grupo){
	
		if($qtd[$grupo]!=0){

			//echo $grupo." ".$qtd[$grupo]."<br>";
			echo '<div class="float-left mr-3 mb-1">
			<div class="card" style="width: 10rem;">
			<div class="card-header bg-success text-white text-center"><b>'.$grupo.'</b> </div>
			<div class="card-body">
			<h1 class="card-text text-center"><b>'.$qtd[$grupo].'</b></h1></div>
		  ';
			if($qtd[$grupo.'main']!=0){
				echo '<div class="card-footer bg-primary"><small class="text-muted text-center"><h2 class="text-white"><i class="fa fa-wrench"></i></h2></small></div>';
			}
		echo '</div></div>';
		}
	

}

	
}

//conta o numero de ventos para o dashboard
function dash_countevent($api){
	$triggers = $api->triggerGet(array(
        'only_true' => 1,
		'filter' =>  (array('value'=>1)),
		'monitored' => 1,
		'active' => 1,
		'skipDependent' => 1,
		'output' => 'extend',
		'expandDescription' => 1,
		'selectLastEvent'=>	'extend',
		'selectHosts' =>  (array('host')),
		'selectGroups' => (array('name')),
		'sortfield'=> 'lastchange',
		'sortorder'=> 'DESC'
		));
		
		$disaster=0;
		$average=0;
		$high =0;
		$warning =0;
		$info =0;
		$notclas=0;
		
		foreach($triggers as $trigger){
	
	$prioridade=$trigger->priority;
	if ($trigger->priority==3){
		$average++;
	}elseif($trigger->priority==4){
		$high++;
	}elseif($trigger->priority==5){
		$disaster++;
	}elseif($trigger->priority==2){
		$warning++;
	}elseif($trigger->priority==1){
		$info++;
	}elseif($trigger->priority==0){
		$notclas++;
	}
		}
		$alta=$average + $high + $disaster ;
		$media=$warning;
		$baixa=$info + $notclas;
$retorno= array($alta,$media,$baixa);
 return $retorno;
	
}

function triggers_active_notmaintance($api){
	$notmaintances = $api->triggerGet(array(
        'only_true' => 1,
		'filter' =>  (array('value'=>1)),
		'maintenance' => 'true',
		'monitored' => 1,
		'active' => 1,
		'skipDependent' => 1,
		'output' => 'extend',
		'expandDescription' => 1,
		'selectLastEvent'=>	'extend',
		'selectHosts' =>  (array('host')),
		'selectGroups' => (array('name')),
		'sortfield'=> 'lastchange',
		'sortorder'=> 'DESC'
		));
		
		
		$retorno=array();
		
		foreach($notmaintances as $notmaintance){
			$hosts = $notmaintance->hosts;
			
			foreach($hosts as $host){
				//echo "Host:".$host->host.'</br>';
				array_push($retorno,$host->host);
					}
			
		}

	return $retorno;
}


function triggers_active($api){
	$triggers = $api->triggerGet(array(
        'only_true' => 1,
		'filter' =>  (array('value'=>1)),
		'monitored' => 1,
		'active' => 1,
		'skipDependent' => 1,
		'output' => 'extend',
		'expandDescription' => 1,
		'selectLastEvent'=>	'extend',
		'selectHosts' =>  (array('host')),
		'selectGroups' => (array('name')),
		'sortfield'=> 'lastchange',
		'sortorder'=> 'DESC'
		));
		
		
		
		foreach($triggers as $trigger){
	
	//echo 'Trigger Ativa:'.$trigger->description;
	$descricao=$trigger->description;
	/*if ($trigger->value==0){
		echo 'Resolvido';
	}elseif($trigger->value==1){
		echo 'Problema';
	}*/
	//echo '<br>';
	$prioridade=verify_priority($trigger->priority);
	//echo 'Trigger Priority:'.verify_priority($trigger->priority);
	//echo '<br>';
	$hosts = $trigger->hosts;
	foreach($hosts as $host){
		//echo "Host:".$host->host.'</br>';
		$hostname=$host->host;
	}
	$groups = $trigger->groups;
	//echo "Grupo:";
	$groupname=' ';
	foreach($groups as $group){
		//echo $group->name."/";
		$groupname=$groupname.$group->name;
		$groupname=$groupname.'/';
	}
	$groupname=$groupname.' ';
	//echo "<br>";
	$events=$trigger->lastEvent;
	$eventid = $trigger->lastEvent->eventid;
	$objectid = $trigger->lastEvent->objectid;
	
	if ($trigger->lastEvent->acknowledged==1){
		$ack=' <span class="badge badge-pill bg-success text-white">ACK</span>';
	}elseif($trigger->lastEvent->acknowledged==0){
		$ack='';
	}
	
	//verifica se o host esta em manutenção
	$notmaintances=triggers_active_notmaintance($api);
	//echo $hostname;
	//print_r($notmaintances);
	$count=0;
	foreach($notmaintances as $notmaintance){
		
	if($hostname == $notmaintance){
		//$maintance='';
		$count++;
	}else{
		
		//$maintance=' <span class="badge badge-pill bg-success text-white">em Manutenção</span>';
	}
		
	}
	if($count!=0){
		$maintance='';
	}else{
		$maintance=' <span class="badge badge-pill bg-success text-white">em Manutenção</span>';
	}
	//echo $eventid;
	//echo $objectid;
	
	
	//foreach($events as $event){
		//$eventid=$event->eventid;
		//$objectid=$event->objectid;
		//echo $eventid;
		//echo $objectid;
		//echo $timeevento;
		
	//}
	$event = new DateTime;
	$event=date('d/m/Y H:i',event_get_detal($eventid,$objectid,$api)); 
	//echo 'Time:'.event_get_detal($eventid,$objectid,$api);
	//$timeevento=event_get_detal($eventid,$objectid,$api);
	//print_r ($triggers);
	//echo date('d/m/Y H:i',$event);
	//echo '<br>';
	//echo '<br>';
	//echo event_get_detal($eventid,$objectid,$api);
	
	//componentes do form
	$link_ack='eventack.php?hostname='.$hostname.'&eventid='.$eventid.'&eventdesc='.$descricao;
	
	echo '<li class="list-group-item m-1">
		<div class="float-right">
		<a class="" href="'.$link_ack.'"><span class="badge badge-pill bg-primary text-white">insert ack</span></a>
		</div>
		<div><span class="badge badge-pill '.$prioridade[1].'">'.$prioridade[0].'</span> <span class="badge badge-pill '.$prioridade[1].'">'.$event.'</span> <span class="badge badge-pill '.$prioridade[1].'"> '.$groupname.'</span>'.$ack.$maintance.'<br> '.$hostname.' - <small><b>'.$descricao.'</b></small></div>
		</li>';
	//echo event_get_detal(3317,14747,$api);
		}
		//print_r ($triggers);

	
}


function verify_priority($priority){
	if ($priority==3){
		$severity='Average';
		$color='bg-danger text-white';
	}elseif($priority==4){
		$severity= 'High text-white';
		$color='bg-danger';
	}elseif($priority==5){
		$severity='Disaster';
		$color='bg-danger text-white';
	}elseif($priority==2){
		$severity='Warning';
		$color='bg-warning';
	}elseif($priority==1){
		$severity= 'Information';
		$color='bg-primary text-white';
	}elseif($priority==0){
		$severity='Not Classified';
		$color='bg-primary';
	}
	$retorno=array($severity,$color);
	return $retorno;
}

function event_get_detal($eventid,$objectid,$api){
	$events = $api->eventGet(array(
		'output' => 'extend',
		'objectids'=> $objectid,
		'sortfield'=> (array('clock'=>'eventid')),
		'filter' => (array('eventid'=>$eventid))
		));
		foreach($events as $event){
		$retorno=$event->clock;
		
	}
	//return date('d/m/Y H:i',$retorno);
	return $retorno;
}

function get_maintance($api){
	$maintances = $api->maintenanceGet(array(
		'output' => 'extend',
		'selectGroups'=> 'extend',
		'selectHosts'=> 'extend'
		));
		
	//return date('d/m/Y H:i',$retorno);
	print_r($maintances);
}

function verify_groupmaintance($api){
	$notmaintances = $api->triggerGet(array(
        'only_true' => 1,
		'filter' =>  (array('value'=>1)),
		'maintenance' => 'true',
		'monitored' => 1,
		'active' => 1,
		'skipDependent' => 1,
		'output' => 'extend',
		'expandDescription' => 1,
		'selectLastEvent'=>	'extend',
		'selectHosts' =>  (array('host')),
		'selectGroups' => (array('name')),
		'sortfield'=> 'lastchange',
		'sortorder'=> 'DESC'
		));
		
		
		$retorno=array();
		
		foreach($notmaintances as $notmaintance){
			$groups = $notmaintance->groups;
			
			foreach($groups as $group){
				//echo "Host:".$host->host.'</br>';
				array_push($retorno,$group->name);
					}
			
		}
		
		
		

	return $retorno;
	//print_r($notmaintances);
}

function all_groups_maintance($api){
	$notmaintances = $api->triggerGet(array(
        'only_true' => 1,
		'filter' =>  (array('value'=>1)),
		'maintenance' => 'true',
		'monitored' => 1,
		'active' => 1,
		'skipDependent' => 1,
		'output' => 'extend',
		'expandDescription' => 1,
		'selectLastEvent'=>	'extend',
		'selectHosts' =>  (array('host')),
		'selectGroups' => (array('name')),
		'sortfield'=> 'lastchange',
		'sortorder'=> 'DESC'
		));
		
		
		$retorno=array();
		
		foreach($notmaintances as $notmaintance){
			$groups = $notmaintance->hosts;
			
			foreach($groups as $group){
				//echo "Host:".$host->host.'</br>';
				array_push($retorno,$group->host);
					}
			
		}
		
		
		

	return $retorno;
	//print_r($notmaintances);
}

function all_groups($api){
	$notmaintances = $api->triggerGet(array(
        'only_true' => 1,
		'filter' =>  (array('value'=>1)),
		'monitored' => 1,
		'active' => 1,
		'skipDependent' => 1,
		'output' => 'extend',
		'expandDescription' => 1,
		'selectLastEvent'=>	'extend',
		'selectHosts' =>  (array('host')),
		'selectGroups' => (array('name')),
		'sortfield'=> 'lastchange',
		'sortorder'=> 'DESC'
		));
		
		
		$retorno=array();
		
		foreach($notmaintances as $notmaintance){
			$groups = $notmaintance->hosts;
			
			foreach($groups as $group){
				//echo "Host:".$host->host.'</br>';
				array_push($retorno,$group->host);
					}
			
		}
		
		
		

	return $retorno;
	//print_r($notmaintances);
}
//triggers_active($api);
//print_r(triggers_active($api));



function verify_group_maintance2($grupo,$api){
	
	$hostsmaintance=all_groups_maintance($api);
	$hosts=all_groups($api);
	
	//print_r($hostsmaintance);
	//print_r($hosts);

	foreach ($hosts as $teste){
			if(in_array($teste,$hostsmaintance)){
				$consulta=0;
			}else{

				$hostgruop=get_hostgroups($teste,$api);
				if(in_array($grupo,$hostgruop)){
					print_r($hostgruop);
					return 1;
				}
			}
	}
	
	
}

function get_hostgroups($host,$api){
	$retorno = $api->hostGet(array(
		'output' => 'extend',
		'selectGroups' => (array('name')),
		'filter' => (array('host'=>$host))
		));
		
		foreach($retorno as $saida){
		$saida2=$saida->groups;
		}
		//print_r($saida2);
	return $saida2;
}


header("Refresh:".$refreshtime);
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title>Dashboard Zabbix R-API</title>

    <!-- Bootstrap CSS CDN -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
    <!-- Our Custom CSS -->
    <link rel="stylesheet" href="./css/dashboard.css">
	
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" crossorigin="anonymous">

    </head>


<body class="bg-light">



<div class="">
<!--painel Alertas-->


<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()"></h1><i class="fa fa-times" aria-hidden="true"></i>
</h1></a>
<div class="card bg-light ">

<div class="card-header bg-dark"><h6 class="text-white card-title"><b>Alarmes Ativos</b></h6></div> 
	  
<div id="collapse1" class="">
<div id="card-body  " style="overflow-y: scroll; height: 500px">
<ul class="list-group" >
 
  <?php 
  triggers_active($api);
  //print_r(triggers_active_notmaintance($api));
  ?>
</ul>
</div>
</div> 
</div> 
</div><!--painel-->



<span onclick="openNav()"><h3><i class="fa fa-bars m-2" aria-hidden="true"></h3></i>
</span>
</div>

<div class="main">
<div class="container">
<div class="row">

<?php
$cards=dash_countevent($api);

?>


	
	<div class="col-sm-4">
	<div class="card text-white bg-danger" style="max-width: 18rem;">
		<div class="card-header">Disaster/Average/High</div>
		<div class="card-body">
			<h1 class="card-text text-white"><b><i class="fa fa-exclamation-triangle mr-3" aria-hidden="true"></i><?php echo $cards[0];  ?></b></h1>
		</div>
	</div>
	</div>

	<div class="col-sm-4">
	<div class="card text-white bg-warning" style="max-width: 18rem;">
		<div class="card-header">Warning</div>
		<div class="card-body">
			<h1 class="card-text text-white"><b><i class="fa fa-exclamation-triangle mr-3" aria-hidden="true"></i><?php echo $cards[1];  ?></b></h1>
		</div>
	</div>
	</div>

	<div class="col-sm-4">
	<div class="card text-white bg-info" style="max-width: 18rem;">
		<div class="card-header">Info/Não classificados</div>
		<div class="card-body">
			<h1 class="card-text text-white"><b><i class="fa fa-exclamation-triangle mr-3" aria-hidden="true"></i><?php echo $cards[2];  ?></b></h1>
		</div>
	</div>
	</div>
	
</div>

<div class="row">
<div class="col-sm-12 m-2">
<h4 class="">Alarmes por Grupo</h4>
</div>


<?php 
//print_r(get_hostgroup($api));
//$posicoes=get_hostgroup($api);
//echo count($posicoes);

dash_countgroups($api);

verify_group_maintance2('Zabbix servers',$api);

//print_r (get_hostgroups('notesempreit2',$api));
?>


</div>

</div><!--coluna2-->
</div>



    <!-- jQuery CDN - Slim version (=without AJAX) -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <!-- Popper.JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
    <!-- Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>
<script>
/* Set the width of the side navigation to 250px and the left margin of the page content to 250px and add a black background color to body */
function openNav() {
    document.getElementById("mySidenav").style.width = "750px";
    document.getElementById("main").style.marginLeft = "500px";
    
}

/* Set the width of the side navigation to 0 and the left margin of the page content to 0, and the background color of body to white */
function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft = "0";
    document.body.style.backgroundColor = "white";
} 
</script>
</body>
<!--criado e desenvolvido por Rodrigo Soares Alves-->
<!--email rodrigo_s.alves@hotmail.com  -->
<!-- facebook page https://www.facebook.com/rodrigo.soares.37604-->
</html>