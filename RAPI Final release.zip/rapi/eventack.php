<?php
$hostname=$_GET['hostname'];
$eventid=$_GET['eventid'];
$eventdesc=$_GET['eventdesc'];
$date=$_GET['date'];

require_once 'lib/ZabbixApi.class.php';
require_once 'conf/conf.php';

use ZabbixApi\ZabbixApi;

//metodos para conectar zabbix
try
{
    // connect to Zabbix API
    $api = new ZabbixApi('http://'.$ip_zbx.'/zabbix/api_jsonrpc.php', $user_zbx, $passwd);

    /* ... do your stuff here ... */
}
catch(Exception $e)
{
    // Exception in ZabbixApi catched
    echo $e->getMessage();
}

function get_events_messages($eventid,$api){
	$events = $api->eventGet(array(
		'eventids' => $eventid,
		'select_acknowledges' => (array('message'))
		));

	//print_r($events);
	foreach($events as $event){
		$messages=$event->acknowledges;
	}
	$contador = 1;
	foreach($messages as $m){
		echo "<tr><th scope=\"row\">".$contador."</th><td>".$m->message."</td><tr>";
		$contador++;
	}
}

?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title>Dashboard Zabbix R-API</title>

    <!-- Bootstrap CSS CDN -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
    <!-- Our Custom CSS -->
    <link rel="stylesheet" href="style.css">

    </head>


<body class="">

<div class="container">


<nav class="navbar navbar-light bg-light m-1">
  <a class="navbar-brand" href="#">Event ACK</a>
</nav>



<!--painel Alertas-->
<div class="col-sm-12">
<div class="card bg-light">

<?php

echo '<div class="bg-light m-1">';
echo '<span class="badge badge-pill bg-secondary text-white">'.$hostname.'</span> ';
echo '<span class="badge badge-pill bg-secondary text-white">'.$eventid.'</span> ';;
echo '<span class="badge badge-pill bg-secondary text-white">'.$eventdesc.'</span> ';
echo '<span class="badge badge-pill bg-secondary text-white">'.$date.'</span> ';
echo '</div>';




?>


<form action="ackpost.php" method="post">
  <div class="form-group m-1">
    <label for="exampleInputEmail1">Reconhecimento do Evento</label>
    <input type="text" name="message" class="form-control m-1" id="message" aria-describedby="emailHelp" placeholder="Descrição">
	<input type="text" name="eventid" class="form-control m-1" id="eventid"  value="<?php echo $eventid;?>" readonly>
  </div>
  <button type="submit" class="btn btn-primary m-1">Submit</button>
  <a href="./dashboard.php"><button type="button" class="btn btn-danger">Cancelar</button></a>
</form>
</div> 
</div><!--painel-->

<!--eventos reconhecidos-->
<div class="card bg-light m-2">
<nav class="navbar navbar-light bg-light m-1">
  <a class="navbar-brand" href="#">Reconhecimento do Evento e mensagens anteriores</a>
</nav>

<table class="table table-sm">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Mensagem</th>
    </tr>
  </thead>
  <tbody>
  
<?php
get_events_messages($eventid,$api);
?>
 </tbody>
</table>

</div>

</div>



    <!-- jQuery CDN - Slim version (=without AJAX) -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <!-- Popper.JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
    <!-- Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>

</body>

</html>