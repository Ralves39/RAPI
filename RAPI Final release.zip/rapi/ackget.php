<?php

require_once 'lib/ZabbixApi.class.php';
require_once 'conf/conf.php';

use ZabbixApi\ZabbixApi;

//metodos para conectar zabbix
try
{
    // connect to Zabbix API
    $api = new ZabbixApi('http://'.$ip_zbx.'/zabbix/api_jsonrpc.php', $user_zbx, $passwd);

    /* ... do your stuff here ... */
}
catch(Exception $e)
{
    // Exception in ZabbixApi catched
    echo $e->getMessage();
}

function get_events_messages($eventid,$api){
	$events = $api->eventGet(array(
		'eventids' => $eventid,
		'select_acknowledges' => (array('message'))
		));

	//print_r($events);
	foreach($events as $event){
		$messages=$event->acknowledges;
	}
	$contador = 1;
	foreach($messages as $m){
		echo "<br>".$contador." - ".$m->message;
		$contador++;
	}
}

$eventid= 186;

get_events_messages($eventid,$api);

echo "teste";
?>